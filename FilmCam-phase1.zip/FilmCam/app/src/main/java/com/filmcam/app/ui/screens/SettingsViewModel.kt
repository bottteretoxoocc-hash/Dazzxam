package com.filmcam.app.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.filmcam.app.preferences.AppSettings
import com.filmcam.app.preferences.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(private val repo: SettingsRepository) : ViewModel() {
    val settings: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    fun setSound(v: Boolean) { viewModelScope.launch { repo.setShutterSound(v) } }
    fun setHaptics(v: Boolean) { viewModelScope.launch { repo.setHaptics(v) } }
    fun setSaveOriginal(v: Boolean) { viewModelScope.launch { repo.setSaveOriginal(v) } }
}
