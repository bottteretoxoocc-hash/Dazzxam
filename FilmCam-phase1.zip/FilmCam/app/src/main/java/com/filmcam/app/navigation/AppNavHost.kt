package com.filmcam.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.filmcam.app.ui.screens.CameraScreen
import com.filmcam.app.ui.screens.GalleryScreen
import com.filmcam.app.ui.screens.SettingsScreen
import com.filmcam.app.ui.screens.ViewerScreen

@Composable
fun AppNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Route.Camera.path) {
        composable(Route.Camera.path) {
            CameraScreen(
                onOpenGallery = { nav.navigate(Route.Gallery.path) },
                onOpenSettings = { nav.navigate(Route.Settings.path) },
            )
        }
        composable(Route.Gallery.path) {
            GalleryScreen(
                onBack = { nav.popBackStack() },
                onOpenPhoto = { nav.navigate(Route.Viewer.create(it)) },
            )
        }
        composable(
            Route.Viewer.path,
            arguments = listOf(navArgument(Route.Viewer.ARG) { type = NavType.LongType }),
        ) { entry ->
            ViewerScreen(
                photoId = entry.arguments?.getLong(Route.Viewer.ARG) ?: 0L,
                onBack = { nav.popBackStack() },
            )
        }
        composable(Route.Settings.path) {
            SettingsScreen(onBack = { nav.popBackStack() })
        }
    }
}
