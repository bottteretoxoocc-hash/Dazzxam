package com.filmcam.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object FilmColors {
    val Body = Color(0xFF0B0B0C)
    val Panel = Color(0xFF1A1A1C)
    val Accent = Color(0xFFFFB02E)
    val OnDark = Color(0xFFF2EFE9)
    val Muted = Color(0xFF8A8780)
}

private val Scheme = darkColorScheme(
    primary = FilmColors.Accent,
    onPrimary = Color.Black,
    background = FilmColors.Body,
    surface = FilmColors.Panel,
    onBackground = FilmColors.OnDark,
    onSurface = FilmColors.OnDark,
)

@Composable
fun FilmCamTheme(content: @Composable () -> Unit) {
    // The camera UI is always dark, regardless of system setting.
    MaterialTheme(colorScheme = Scheme, content = content)
}
