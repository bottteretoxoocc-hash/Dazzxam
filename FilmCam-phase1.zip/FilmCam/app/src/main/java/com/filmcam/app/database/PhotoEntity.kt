package com.filmcam.app.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photos")
data class PhotoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val processedUri: String,          // MediaStore content:// URI of the film-processed JPEG
    val originalUri: String?,          // optional untouched capture
    val presetId: String,
    val paramsJson: String,            // snapshot of FilmParams used, so the look is reproducible
    val width: Int,
    val height: Int,
    val takenAtMillis: Long,
)
