package com.filmcam.app.filmpresets

enum class CameraType { CCD, FILM_35MM, DISPOSABLE, POINT_AND_SHOOT, INSTANT, RETRO_DIGITAL, CAMCORDER, MONO }

enum class FrameStyle { NONE, WHITE_POLAROID, BLACK_FILM_STRIP, THIN_WHITE }

/**
 * Every tunable of the shader pipeline (Phase 3 consumes these as uniforms).
 * All values are normalised floats so presets can be blended / user-adjusted at runtime.
 */
data class FilmParams(
    val temperature: Float = 0f,       // -1 cool .. +1 warm
    val tint: Float = 0f,              // -1 green .. +1 magenta
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val fade: Float = 0f,              // lifts blacks
    val highlightRolloff: Float = 0.5f,
    val shadowTint: Triple<Float, Float, Float> = Triple(0f, 0f, 0f),
    val highlightTint: Triple<Float, Float, Float> = Triple(0f, 0f, 0f),
    val grain: Float = 0f,
    val grainSize: Float = 1f,
    val vignette: Float = 0f,
    val halation: Float = 0f,
    val bloom: Float = 0f,
    val chromaticAberration: Float = 0f,
    val lensDistortion: Float = 0f,
    val lightLeak: Float = 0f,
    val dust: Float = 0f,
    val retroFlash: Float = 0f,
    val scanlines: Float = 0f,
    val dateStamp: Boolean = false,
)

data class FilmPreset(
    val id: String,
    val displayName: String,
    val type: CameraType,
    val aspectRatio: Float,            // width / height of the final frame
    val frame: FrameStyle,
    val params: FilmParams,
)
