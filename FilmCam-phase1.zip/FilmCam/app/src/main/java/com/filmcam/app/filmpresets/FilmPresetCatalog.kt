package com.filmcam.app.filmpresets

/** Original preset catalogue. Values are starting points to be tuned on real devices in Phase 4. */
object FilmPresetCatalog {

    val all: List<FilmPreset> = listOf(
        FilmPreset(
            id = "ccd_y2k", displayName = "CCD 2003", type = CameraType.CCD,
            aspectRatio = 4f / 3f, frame = FrameStyle.NONE,
            params = FilmParams(
                temperature = 0.05f, contrast = 1.12f, saturation = 1.15f, highlightRolloff = 0.2f,
                grain = 0.12f, vignette = 0.18f, bloom = 0.25f, chromaticAberration = 0.15f,
                retroFlash = 0.5f, dateStamp = true,
            ),
        ),
        FilmPreset(
            id = "film_gold_400", displayName = "Gold 400", type = CameraType.FILM_35MM,
            aspectRatio = 3f / 2f, frame = FrameStyle.NONE,
            params = FilmParams(
                temperature = 0.25f, tint = 0.05f, contrast = 1.08f, saturation = 1.1f, fade = 0.06f,
                highlightRolloff = 0.7f, shadowTint = Triple(0.02f, 0.05f, 0.08f),
                grain = 0.45f, grainSize = 1.2f, vignette = 0.3f, halation = 0.35f, dust = 0.2f,
            ),
        ),
        FilmPreset(
            id = "disposable_27", displayName = "Disposable 27", type = CameraType.DISPOSABLE,
            aspectRatio = 3f / 2f, frame = FrameStyle.NONE,
            params = FilmParams(
                temperature = 0.15f, tint = -0.05f, contrast = 1.2f, saturation = 1.25f, fade = 0.1f,
                grain = 0.6f, vignette = 0.5f, lensDistortion = 0.15f, lightLeak = 0.35f,
                retroFlash = 0.8f, dust = 0.3f, dateStamp = true,
            ),
        ),
        FilmPreset(
            id = "pns_90s", displayName = "Compact 90", type = CameraType.POINT_AND_SHOOT,
            aspectRatio = 3f / 2f, frame = FrameStyle.NONE,
            params = FilmParams(
                temperature = 0.1f, contrast = 1.1f, saturation = 1.05f, fade = 0.04f,
                grain = 0.3f, vignette = 0.35f, halation = 0.2f, retroFlash = 0.6f, dateStamp = true,
            ),
        ),
        FilmPreset(
            id = "instant_sq", displayName = "Instant SQ", type = CameraType.INSTANT,
            aspectRatio = 1f, frame = FrameStyle.WHITE_POLAROID,
            params = FilmParams(
                temperature = -0.05f, tint = 0.08f, contrast = 0.95f, saturation = 0.9f, fade = 0.18f,
                highlightRolloff = 0.85f, shadowTint = Triple(0.05f, 0.06f, 0.1f),
                grain = 0.2f, vignette = 0.25f, bloom = 0.3f, lightLeak = 0.15f,
            ),
        ),
        FilmPreset(
            id = "retro_digi", displayName = "Digi 2001", type = CameraType.RETRO_DIGITAL,
            aspectRatio = 4f / 3f, frame = FrameStyle.NONE,
            params = FilmParams(
                temperature = -0.1f, contrast = 1.05f, saturation = 0.95f,
                grain = 0.25f, chromaticAberration = 0.3f, scanlines = 0.2f, dateStamp = true,
            ),
        ),
        FilmPreset(
            id = "cam_hi8", displayName = "Cam Hi8", type = CameraType.CAMCORDER,
            aspectRatio = 4f / 3f, frame = FrameStyle.NONE,
            params = FilmParams(
                temperature = 0.05f, contrast = 1.1f, saturation = 0.85f, fade = 0.08f,
                grain = 0.35f, vignette = 0.3f, chromaticAberration = 0.4f, scanlines = 0.6f, dateStamp = true,
            ),
        ),
        FilmPreset(
            id = "mono_hp5", displayName = "Mono 400", type = CameraType.MONO,
            aspectRatio = 3f / 2f, frame = FrameStyle.BLACK_FILM_STRIP,
            params = FilmParams(
                contrast = 1.25f, saturation = 0f, fade = 0.05f, highlightRolloff = 0.6f,
                grain = 0.7f, grainSize = 1.4f, vignette = 0.35f, dust = 0.25f,
            ),
        ),
    )

    fun byId(id: String): FilmPreset = all.firstOrNull { it.id == id } ?: all.first()
}
