package com.filmcam.app.di

import android.content.Context
import androidx.room.Room
import com.filmcam.app.database.AppDatabase
import com.filmcam.app.database.PhotoDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "filmcam.db").build()

    @Provides
    fun providePhotoDao(db: AppDatabase): PhotoDao = db.photoDao()
}
