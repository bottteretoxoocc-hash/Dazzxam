package com.filmcam.app.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

data class AppSettings(
    val shutterSound: Boolean = true,
    val haptics: Boolean = true,
    val saveOriginal: Boolean = false,
    val lastPresetId: String = "ccd_y2k",
)

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val context: Context) {

    private object Keys {
        val SOUND = booleanPreferencesKey("shutter_sound")
        val HAPTICS = booleanPreferencesKey("haptics")
        val SAVE_ORIGINAL = booleanPreferencesKey("save_original")
        val LAST_PRESET = stringPreferencesKey("last_preset")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            shutterSound = p[Keys.SOUND] ?: true,
            haptics = p[Keys.HAPTICS] ?: true,
            saveOriginal = p[Keys.SAVE_ORIGINAL] ?: false,
            lastPresetId = p[Keys.LAST_PRESET] ?: "ccd_y2k",
        )
    }

    suspend fun setShutterSound(v: Boolean) { context.dataStore.edit { it[Keys.SOUND] = v } }
    suspend fun setHaptics(v: Boolean) { context.dataStore.edit { it[Keys.HAPTICS] = v } }
    suspend fun setSaveOriginal(v: Boolean) { context.dataStore.edit { it[Keys.SAVE_ORIGINAL] = v } }
    suspend fun setLastPreset(id: String) { context.dataStore.edit { it[Keys.LAST_PRESET] = id } }
}
