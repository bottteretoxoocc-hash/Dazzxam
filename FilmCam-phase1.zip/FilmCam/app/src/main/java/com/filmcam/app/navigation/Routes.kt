package com.filmcam.app.navigation

sealed class Route(val path: String) {
    data object Camera : Route("camera")
    data object Gallery : Route("gallery")
    data object Settings : Route("settings")
    data object Viewer : Route("viewer/{photoId}") {
        const val ARG = "photoId"
        fun create(id: Long) = "viewer/$id"
    }
}
