package com.filmcam.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.filmcam.app.ui.theme.FilmColors

@Composable
fun CameraScreen(onOpenGallery: () -> Unit, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    Box(Modifier.fillMaxSize().background(FilmColors.Body).systemBarsPadding()) {
        if (!granted) {
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text("Camera access is needed to take photos.", color = FilmColors.OnDark)
                Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
            }
        } else {
            // Phase 2 replaces this with the live preview + controls.
            Text("Camera ready", color = FilmColors.Muted, modifier = Modifier.align(Alignment.Center))
        }
        Row(Modifier.align(Alignment.TopEnd).padding(8.dp)) {
            IconButton(onClick = onOpenGallery) { Icon(Icons.Filled.PhotoLibrary, "Gallery", tint = FilmColors.OnDark) }
            IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, "Settings", tint = FilmColors.OnDark) }
        }
    }
}
