package com.filmcam.app.repository

import com.filmcam.app.database.PhotoDao
import com.filmcam.app.database.PhotoEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PhotoRepository @Inject constructor(private val dao: PhotoDao) {
    fun observePhotos(): Flow<List<PhotoEntity>> = dao.observeAll()
    suspend fun get(id: Long): PhotoEntity? = dao.getById(id)
    suspend fun add(photo: PhotoEntity): Long = dao.insert(photo)
    suspend fun remove(photo: PhotoEntity) = dao.delete(photo)
}
