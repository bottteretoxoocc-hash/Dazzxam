# FilmCam – Phase 1: Architecture

## Layers (clean architecture, MVVM)
- **ui/** Compose screens + ViewModels (state in, events out). No camera/GL code.
- **repository/** Single source of truth for photos (Room + MediaStore in Phase 5).
- **database/, preferences/** Room (photo metadata + preset snapshot), DataStore (settings).
- **cameraengine/** CameraX session, Camera2 interop (exposure, focus, zoom), lifecycle. (Phase 2)
- **imageprocessing/** + **shaders/** GLES 3.0 pipeline: camera OES texture -> film passes -> preview surface AND capture surface. (Phase 3)
- **filmpresets/** Data-only presets (`FilmParams` -> shader uniforms).
- **di/** Hilt modules. **navigation/** Navigation Compose routes.

## Pipeline (built in Phases 2-3)
CameraX Preview/ImageCapture -> SurfaceTexture (OES) -> single GL renderer
 1. Lens distortion / chromatic aberration (UV pass)
 2. Color: white balance, contrast, fade, highlight roll-off, split-tone
 3. Halation + bloom (downsampled blur, additive)
 4. Grain, dust, light leak, scanlines, vignette
 5. Date stamp + frame (capture only)
The **same shader and uniforms** render the preview and the saved photo, which guarantees WYSIWYG consistency. Capture re-renders the full-resolution frame offscreen (FBO) with identical params, with grain scaled to resolution.

## Phase 1 status
Project builds structure, DI, navigation, Room, DataStore, preset catalogue and permission-gated camera shell.
Open in Android Studio (Koala+), let it sync (it generates the Gradle wrapper), then Run.
